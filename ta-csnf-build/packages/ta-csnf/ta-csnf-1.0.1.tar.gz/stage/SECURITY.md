# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| > 1.0   | :white_check_mark: |

## Reporting a Vulnerability

You may use the GitHub [Issues](https://github.com/onug/CSNF/issues) page to report any vulnerability. We do not, currently, have any SLA on fixes to our open source projects but do try to support them on a best effort basis. 